package ilterzocchio.mock001;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import  java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    private Socket socket;

    private String ip = "127.0.0.1";
    private int port = 9525;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnTime = findViewById(R.id.btnTime);
        final TextView lblTime = findViewById(R.id.lblTime);

        new Thread(new ClientThread()).start();

        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String answer = "";
                try {
                    //lblTime.setText("Dentro2");
                    BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    answer = input.readLine();
                    input.close();
                }catch (Exception e) {
                    answer = e.getMessage();
                    /*answer +=  " - " + e.getClass().toString();*/
                    /*answer += " - " + e.getCause().toString();*/
                }

                lblTime.setText(answer);
            }
        });
    }


    class ClientThread implements Runnable {
        @Override
        public void run() {
            final TextView lblThread = findViewById(R.id.lblThread);
            String result;

            try {
                InetAddress serverAddr = InetAddress.getByName(ip);
                socket = new Socket(serverAddr, port);
                if(socket == null){
                    result = "1 - Socket:null";
                }else{
                    result = "2 - Its working";
                }
            } catch (UnknownHostException e1) {
                result = "3 - " + e1.getMessage();
            } catch (IOException e1) {
                result = "4 - " + e1.getMessage();
            }

            lblThread.setText(result);
        }
    }


}


