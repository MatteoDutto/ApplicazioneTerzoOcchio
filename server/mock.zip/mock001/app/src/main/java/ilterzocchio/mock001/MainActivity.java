package ilterzocchio.mock001;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import  java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private String ip = "192.168.42.23";
    private int port = 9525;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnTime = findViewById(R.id.btnTime);
        final TextView lblTime = findViewById(R.id.lblTime);

        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        lblTime.setText("Negrozio");


                        /*String answer;
                        lblTime.setText("");
                        lblTime.setText(lblTime.getText() + "Dentro");

                        try {
                            Socket sock;
                            sock = new Socket(ip, port);
                            lblTime.setText("Dentro2");

                            BufferedReader input = new BufferedReader(new InputStreamReader(sock.getInputStream()));
                            answer = input.readLine();

                            input.close();
                            sock.close();

                        } catch (IOException e) {
                            answer = e.getMessage();
                        }

                        lblTime.setText(answer);*/
                    }
                });
            }
        });
    }
}


