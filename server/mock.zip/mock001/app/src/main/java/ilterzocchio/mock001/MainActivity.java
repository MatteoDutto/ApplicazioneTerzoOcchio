package ilterzocchio.mock001;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import  java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    private Socket socket;
    private boolean connected = false;
    private String ip = "127.0.0.1";
    private int port = 9525;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        final EditText txtIp = findViewById(R.id.txtIp);
        final EditText txtPort = findViewById(R.id.txtPort);
        Button btnConnetti = findViewById(R.id.btnConnetti);
        Button btnRequest = findViewById(R.id.btnRquest);
        final TextView lblAnswer = findViewById(R.id.lblAnswer);


        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(connected){
                    lblAnswer.setText(s_recv(socket));
                }
                lblAnswer.setText("Socket not connected");
            }
        });

        btnConnetti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Get Ip and Port*/
                ip = txtIp.getText().toString();
                port = Integer.parseInt(txtPort.getText().toString());
                try{
                    new Thread(new ClientThread()).start();
                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                }

                /*Start Thread*/

            }
        });
    }

    /**
     * Thread: server connection
     */
    class ClientThread implements Runnable {
        @Override
        public void run() {
            String result = "Socket: null";
            try {
                InetAddress serverAddr = InetAddress.getByName(ip);
                socket = new Socket(serverAddr, port);
                if(socket != null){
                    result = "Connected";
                    connected = true;
                }
            } catch (UnknownHostException e1) {
                result = e1.getMessage();
            } catch (IOException e1) {
                result =  e1.getMessage();
            }
            catch (Exception e1){
                result = e1.getMessage();
            }
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG);

        }
    }

    /**
     *
     * @param s Socket
     * @return Il messaggio se è stato ricevuto; IOException.getMessage() se c'è stato un errore
     */
    public String s_recv(Socket s){
        String ret = "";
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            ret = input.readLine();
        } catch (IOException e) {
            ret = e.getMessage();
        }
        return ret;
    }

    /**
     *
     * @param s Socket
     * @return NULL se è riuscito a inviare il messaggio; IOException.getMessage() se non ha funzionato
     */
    public String s_send(Socket s){
        String ret = null;
        try {
            BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        } catch (IOException e) {
            ret = e.getMessage();
        }
        return ret;
    }


}


