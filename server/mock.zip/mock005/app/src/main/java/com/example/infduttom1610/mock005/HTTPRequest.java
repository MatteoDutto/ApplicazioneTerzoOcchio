package com.example.infduttom1610.mock005;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by inf.duttom1610 on 13/04/2019.
 */

public class HTTPRequest {

    public void method(){

        /** Frammento di codice da copiare
         *
         * Aggiungere la stringa url_s in R.strings
         * Aggiungere i permessi internet nel manifest:
         *  <uses-permission android:name="android.permission.INTERNET" />
         *  <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
         */
        new Thread(new Runnable(){
            @Override
            public void run() {

                /*----Da inserire in R.strings----*/
                String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
                /*----------*/

                String answer;
                try {
                    URL url = new URL(url_s);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    answer = br.readLine();
                } catch (MalformedURLException e) {
                    //Non dovrebbe succedere
                    answer = "Error: Malformed URL\nMessage: " + e.getMessage();
                } catch (IOException e) {
                    answer = "Error: IOException\nMessage:" + e.getMessage();
                } catch (Exception e) {
                    answer = "Error: Undefined Error\nMessage: " + e.getMessage();
                }
            }
        }).start();

        /*Fine del frammento di codice da copiare*/
    }
}
