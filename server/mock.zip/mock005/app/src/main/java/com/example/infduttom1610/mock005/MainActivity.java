package com.example.infduttom1610.mock005;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.server_client_communication.Comm;

import org.json.JSONArray;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.sql.CommonDataSource;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRequest = findViewById(R.id.btnRequest);
        final TextView lblData = findViewById(R.id.lblData);
        Button btnSend = findViewById(R.id.btnSend);
        final String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Comm comunicazioni = new Comm();
                    lblData.setText(comunicazioni.getLocation(true));
                    Toast.makeText(getApplicationContext(), "Sono arrivato qui", Toast.LENGTH_LONG).show();
                } catch (MalformedURLException e) {
                    e.printStackTrace();

                }catch (Exception e){
                    e.printStackTrace();
                }
                /*try {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String answer = "";
                            try {
                                URL url = new URL("http://fiumeeitaliana.altervista.org/tesina/server_php.php");
                                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                //answer += "Arrivato ; ";

                                urlConnection.setDoOutput(true);
                                //urlConnection.setChunkedStreamingMode(0);

                                OutputStreamWriter out = new OutputStreamWriter(urlConnection.getOutputStream());
                                BufferedWriter bw = new BufferedWriter(out);
                                bw.write("LOGIN");
                                bw.close();

                                urlConnection.setDoOutput(false);
                                urlConnection.setDoInput(true);

                                InputStreamReader in = new InputStreamReader(urlConnection.getInputStream());
                                BufferedReader br = new BufferedReader(in);
                                answer = br.readLine();
                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                                answer += e.getMessage() + "; 1";
                            } catch (IOException e) {
                                e.printStackTrace();
                                answer += e.getMessage()  + "; 2";
                            } catch (Exception e){
                                e.printStackTrace();
                                answer += e.getMessage()  + "; 3";
                            }

                            lblData.setText(answer);
                        }
                    }).start();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Sono successe cose" + e.getMessage(), Toast.LENGTH_LONG);
                }*/

            }
        });

        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    new Thread(new Runnable() {
                        @Override
                        public void run() {

                            String answer = "Nothing";
                            ArrayList<Float[]> coordinate = new ArrayList<>();

                            try {
                                URL url = new URL(url_s);
                                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                InputStreamReader in = new InputStreamReader(urlConnection.getInputStream());
                                BufferedReader br = new BufferedReader(in);
                                answer = br.readLine();
                            } catch (MalformedURLException e) {
                                answer = e.getMessage();
                            } catch (IOException e) {
                                answer = e.getMessage();
                            } catch (Exception e) {
                                answer = e.getMessage();
                                e.printStackTrace();
                            }

                            for(String luogo : answer.split(";")){
                                String[] temp = luogo.split(",");
                                Float[] temp_arr = new Float[2];
                                temp_arr[0] = Float.parseFloat(temp[0]);
                                temp_arr[1] = Float.parseFloat(temp[1]);
                                coordinate.add(temp_arr);
                            }

                            lblData.setText("");
                            for(Float[] luogo : coordinate){
                                lblData.setText(lblData.getText().toString() +
                                         luogo[0].toString() +" - "
                                        + luogo[1].toString() + ";\n");
                            }
                        }
                    }).start();

                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                }
            }
        });



    }


}
