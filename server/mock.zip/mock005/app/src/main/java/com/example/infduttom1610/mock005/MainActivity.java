package com.example.infduttom1610.mock005;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText txtUrl = findViewById(R.id.txtUrl);
        Button btnRequest = findViewById(R.id.btnRequest);
        final TextView lblData = findViewById(R.id.lblData);

        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
                            String answer = "Nothing";
                            ArrayList<Float[]> coordinate = new ArrayList<>();

                            try {
                                URL url = new URL(url_s);
                                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                InputStreamReader in = new InputStreamReader(urlConnection.getInputStream()); //ERRROR
                                BufferedReader br = new BufferedReader(in);
                                answer = br.readLine();
                            } catch (MalformedURLException e) {
                                answer = e.getMessage();
                            } catch (IOException e) {
                                answer = e.getMessage();
                            } catch (Exception e) {
                                answer = e.getMessage();
                                e.printStackTrace();
                            }

                            for(String luogo : answer.split(";")){
                                String[] temp = luogo.split(",");
                                Float[] temp_arr = new Float[2];
                                temp_arr[0] = Float.parseFloat(temp[0]);
                                temp_arr[1] = Float.parseFloat(temp[1]);
                                coordinate.add(temp_arr);
                            }

                            for(Float[] luogo : coordinate){
                                lblData.setText(lblData.getText().toString() + "\n1: "
                                        + luogo[0].toString() +" - "
                                        + luogo[1].toString() + ";");
                            }
                        }
                    }).start();

                } catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                }



            }
        });

    }

    /**
     * Thread: server connection

    class ClientThread implements Runnable {
        @Override
        public void run() {

        }
    }*/
}
