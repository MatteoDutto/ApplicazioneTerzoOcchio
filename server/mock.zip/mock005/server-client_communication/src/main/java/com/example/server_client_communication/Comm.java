package com.example.server_client_communication;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Comm{

    private String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
    private URL url;
    private String answer;

    public Comm() throws MalformedURLException {
        url = new URL(url_s);
    }

    private String connect(final String request) throws Exception{
        new Thread(new Runnable() {
            @Override
            public void run() {
                answer = "BOTTASSOOOOOOOOOOOOOOOOO";
                BufferedWriter bw = null;
                BufferedReader br = null;
                try {

                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    //urlConnection.setDoOutput(true);

                    /*bw = new BufferedWriter(new OutputStreamWriter(urlConnection.getOutputStream()));
                    bw.write(request);*/

                    br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    System.out.printf(answer);
                    answer = String.valueOf(br.read());
                    System.out.println(answer);

                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        //bw.close();
                        br.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        System.out.println("Arrivato");
        //System.out.println(answer);
        return answer;
    }

    /*
    public int login(String userName, String userPassword){
        int user_id = -1;
        String psw_hash = "Ciau";
        String request_ret = connect("LOGIN;user=" + userName + ";psw=" + psw_hash);
        if( request_ret != null){
            user_id = Integer.parseInt(request_ret);
        }
        return user_id;
    }*/

    public ArrayList<Float[]> getLocations() throws Exception {
        ArrayList<Float[]> coordinates = new ArrayList<>();

        String conn_res = connect("Locations");
        String[] temp = conn_res.split(";");

        for(String loc : temp){
            String[] t2 =  loc.split(",");
            Float[] t3 = new Float[2];
            t3[0] = Float.parseFloat(t2[0]);
            t3[1] = Float.parseFloat(t2[1]);
            coordinates.add(t3);
        }

        return coordinates;
    }

    public String getLocation(boolean b) throws Exception {

        return connect("Location");
    }

    public String ciao(){
        return "Grrrz" ;
    }
    /*Lettura del qr
    * Prendere i punti*/

}
