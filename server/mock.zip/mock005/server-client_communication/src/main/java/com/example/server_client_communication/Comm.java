package com.example.server_client_communication;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Comm{

    private String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
    private URL url;
    private String answer;

    public Comm() throws MalformedURLException {
        url = new URL(url_s);
    }

    private String connect(final String request){
        new Thread(new Runnable() {
            @Override
            public void run() {
                answer = null;
                try {

                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setDoOutput(true);

                    OutputStreamWriter out = new OutputStreamWriter(urlConnection.getOutputStream());
                    BufferedWriter bw = new BufferedWriter(out);
                    bw.write(request);
                    bw.close();

                    InputStreamReader in = new InputStreamReader(urlConnection.getInputStream());
                    BufferedReader br = new BufferedReader(in);
                    answer = br.readLine();

                } catch (IOException e) {
                    //e.printStackTrace();
                }
            }
        }).start();
        return answer;
    }

    public int login(String userName, String userPassword){
        int user_id = -1;
        String psw_hash = "Ciau";
        String request_ret = connect("LOGIN;user=" + userName + ";psw=" + psw_hash);
        if( request_ret != null){
            user_id = Integer.parseInt(request_ret);
        }
        return user_id;
    }

    /*Lettura del qr
    * Prendere i punti*/

}
