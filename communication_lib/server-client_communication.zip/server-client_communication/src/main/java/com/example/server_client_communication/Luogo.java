package com.example.server_client_communication;

public class Luogo {

    private String nome = null;
    private String categoria = null;
    private String periodo = null;
    private String testo = null;

    public Luogo(String nome, String categoria, String periodo, String testo) {
        this.nome = nome;
        this.categoria = categoria;
        this.periodo = periodo;
        this.testo = testo;
    }

    public String getNome() {
        return nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getPeriodo() {
        return periodo;
    }

    public String getTesto() {
        return testo;
    }
}
