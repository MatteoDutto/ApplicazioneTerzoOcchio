package com.example.server_client_communication;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.LinkedBlockingQueue;

public class Comm{

    private String url_s = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
    private URL url;
    private String answer;
    private LinkedBlockingQueue q;

    public Comm() throws MalformedURLException {
        url = new URL(url_s);
        q = new LinkedBlockingQueue<String>();
    }

    private String connect(final String request){
        new Thread(new Runnable() {
            @Override
            public void run() {
                answer = "Davideeeeeee";
                BufferedWriter bw = null;
                BufferedReader br = null;
                try {

                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    //urlConnection.setDoOutput(true);

                    /*bw = new BufferedWriter(new OutputStreamWriter(urlConnection.getOutputStream()));
                    bw.write(request);*/

                    br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    answer = br.readLine();
                    if(answer == null){
                        answer = "E' successo un bordello";
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        //bw.close();
                        br.close();
                    } catch (Exception e) {
                        answer = "Dio porco";
                    }
                }

                try {
                    q.put(answer);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        try {
            answer = (String) q.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return answer;
    }


    public String getLocation(){
        return connect("Location");
    }

    /*Lettura del qr
    * Prendere i punti*/

    public String funzia(){
        return "We";
    }

}