package com.example.server_client_communication;

import org.omg.CORBA.NameValuePair;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

public class Comm{

    private String url_s = "http://fiumeeitaliana.altervista.org/tesina/server.php?";
    private URL url;
    private String answer;
    private LinkedBlockingQueue q;

    public Comm() throws MalformedURLException {
        url = new URL(url_s);
        q = new LinkedBlockingQueue<String>();
    }

    public String getLocation(){
        return connect_prendi();
    }

    public String send(){
        return connect_prendi();
    }

    public String connect(final String request){
        new Thread(new Runnable() {
            @Override
            public void run() {
                answer = "Davideeeeeee";
                //BufferedWriter bw = null;
                //BufferedReader br = null;
                OutputStream out;
                try {
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    out = new BufferedOutputStream(urlConnection.getOutputStream());
                    BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));
                    List<NameValuePair> params = new ArrayList<>();
                    String firstParam = "Ciau";
                    /*params.add(new NameValuePair("firstParam", firstParam));

                    wr.write();*/
                    wr.flush();
                    wr.close();
                    out.close();

                    urlConnection.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    q.put(answer);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }).start();
        try {
            answer = (String) q.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return answer;
    }

    public String connect_prendi() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                answer = "";
                String result = "";
                BufferedReader br = null;

                try {
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                    while(answer!=null) {
                        result += answer;
                        answer = br.readLine();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        br.close();
                    } catch (Exception e) {
                        answer = "Errore Linea 147; \n \n";
                        answer = e.getMessage();

                    }
                }

                answer = result;
                try {
                    q.put(answer);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        try {
            answer = (String) q.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return answer;
    }

    public void vediamoSeAggiorna(){}

    public int man(){
        return  0;
    }
}

