package com.example.server_client_communication;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * API per comunicare con il server
 */

public class TerzoOcchio_Server {

    private String string_url = "http://fiumeeitaliana.altervista.org/tesina/baseHTTP.php";
    private URL server_url;
    private String answer;
    private LinkedBlockingQueue thread_queque;

    public TerzoOcchio_Server() throws MalformedURLException {
        server_url = new URL(string_url);
        thread_queque = new LinkedBlockingQueue();
    }

    public ArrayList<String> getQrData(String qr_string){

        /*Extract Data*/

        /*Connect*/

        /*Present Data*/


        return new ArrayList<>(); //Place Holder
    }
}
