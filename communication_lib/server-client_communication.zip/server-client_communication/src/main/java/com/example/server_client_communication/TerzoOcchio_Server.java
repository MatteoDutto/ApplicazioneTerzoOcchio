package com.example.server_client_communication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * API per comunicare con il server
 */

public class TerzoOcchio_Server {

    private String string_url = "http://fiumeeitaliana.altervista.org/tesina/server.php?";
    private URL server_url = null;
    private String ret;
    private LinkedBlockingQueue thread_queque;

    public TerzoOcchio_Server() {
        thread_queque = new LinkedBlockingQueue();
    }

    private String getData(final String request) throws MalformedURLException {

        new Thread(new Runnable() {
            @Override
            public void run() {
                BufferedReader br = null;
                String answer = "";
                String request_url = string_url + request;
                try {
                    server_url = new URL(request_url);
                } catch (MalformedURLException e) {
                }

                try {
                    HttpURLConnection urlConnection = (HttpURLConnection) server_url.openConnection();
                    br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                    String temp = "";
                    while(temp != null){
                        answer += temp;
                        temp = br.readLine();
                    }

                    br.close();
                    urlConnection.disconnect();

                } catch (IOException e) {}

                try {
                    thread_queque.put(answer);
                } catch (InterruptedException e) {}


            }
        }).start();

        server_url = null;

        try {
            ret = (String) thread_queque.take();
        } catch (InterruptedException e) { }

        return ret;
    }

    public ArrayList<Location> location() throws MalformedURLException {

        String request = "TYPE=coordinate";
        String answer = getData(request);
        ArrayList<Location> locations = new ArrayList<Location>();


        for(String row : answer.substring(6).split(";")){
            try{
                String[] temp_row = row.split(",");
                locations.add(new Location(Integer.valueOf(temp_row[0]), Double.valueOf(temp_row[1]), Double.valueOf(temp_row[2])));
            } catch (NullPointerException e){
            }
        }

        return locations;
    }

    public ArrayList<Location> login(String username, String password) throws MalformedURLException {

        String request = "TYPE=login&MAIL=" + username;
        String answer = getData(request);
        String psw = "Errore";
        for(String val : answer.split("PSW=")){
            psw = val;
        }

        psw.replaceAll("\\s+","");
        psw.replaceAll("\\n+","");

        if(!psw.equals(password)){
            //return new ArrayList<Location>();
        }

        return location();
    }

    public Luogo getQrData(String n_pagina) throws MalformedURLException {

        String request = "YPE=qrcode&PAGINA=" + n_pagina;
        String answer = getData(request);

        String[] luogo = answer.split("=")[1].split(";");

        return new Luogo(luogo[0], luogo[1], luogo[2], luogo[3]);
    }
}
