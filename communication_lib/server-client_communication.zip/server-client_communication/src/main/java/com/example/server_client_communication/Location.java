package com.example.server_client_communication;

public class Location {

    private int id = 0;
    private double latitudine = 0.0;
    private double longitudine = 0.0;

    public Location(int id, double latitudine, double longitudine) {
        this.id = id;
        this.latitudine = latitudine;
        this.longitudine = longitudine;
    }

    public Location() {
    }

    public int getId() {
        return id;
    }

    public double getLatitudine() {
        return latitudine;
    }

    public double getLongitudine() {
        return longitudine;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLatitudine(double latitudine) {
        this.latitudine = latitudine;
    }

    public void setLongitudine(double longitudine) {
        this.longitudine = longitudine;
    }
}
