package com.example.tester;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.server_client_communication.Luogo;
import com.example.server_client_communication.TerzoOcchio_Server;

import java.net.MalformedURLException;

public class Pagine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagine);

        final EditText txtPagina = findViewById(R.id.txtPagina);
        Button btnPagina = findViewById(R.id.btnPagina);
        final TextView lblPagina = findViewById(R.id.lblPagina);

        btnPagina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pagina = String.valueOf(txtPagina.getText());
                TerzoOcchio_Server server = new TerzoOcchio_Server();
                Luogo luogo = new Luogo("Errore", "Errore", "Errore", "Errore");
                String result = "Errore";

                try {
                    luogo = server.getQrData(pagina);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }

                result = luogo.getNome() + "\n";
                result += luogo.getCategoria() + " - " + luogo.getPeriodo() + "\n";
                result += "\n" + luogo.getTesto();

                lblPagina.setText(result);
            }
        });
    }
}
