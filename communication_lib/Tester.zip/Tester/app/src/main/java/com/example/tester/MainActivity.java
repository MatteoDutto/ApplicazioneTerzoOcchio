package com.example.tester;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.server_client_communication.Location;
import com.example.server_client_communication.TerzoOcchio_Server;

import java.net.MalformedURLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText txtUsername = findViewById(R.id.txtUsername);
        final EditText txtPassword = findViewById(R.id.txtPassword);
        Button btnCoord = findViewById(R.id.btnCoord);
        final TextView lblCoordinate = findViewById(R.id.lblCoordinate);

        btnCoord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                TerzoOcchio_Server server = new TerzoOcchio_Server();
                ArrayList<Location> locations ;

                lblCoordinate.setText("");
                try {
                     locations = server.login(String.valueOf(txtUsername.getText()), String.valueOf(txtPassword.getText()));

                    for(Location location : locations){
                        result += location.getId() + ": " +
                                location.getLatitudine() + "," +
                                location.getLongitudine() + ";\n";
                    }

                } catch (MalformedURLException e) {
                    result = e.getMessage();
                }


                lblCoordinate.setText("arrivato\n\n\n\n" + result);


            }
        });
    }
}
