package com.example.infduttom1610.mock007;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.server_client_communication.Comm;

import org.w3c.dom.Text;

import java.net.MalformedURLException;

public class MainActivity extends AppCompatActivity {

    private Comm comu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCoord = findViewById(R.id.btnCoord);
        final TextView lblCoord = findViewById(R.id.lblCoord);
        try {
            comu = new Comm();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        btnCoord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lblCoord.setText(comu.getLocation());

            }
        });
    }
}
