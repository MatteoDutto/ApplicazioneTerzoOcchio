package com.example.infduttom1610.unittester;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Coordinate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coordinate);

        Button btnCoord = findViewById(R.id.btnCoord);
        final TextView lblCoord = findViewById(R.id.lblCoord);

        /*btnCoord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer;
                try {
                    Comm comunicazione = new Comm();
                    answer = comunicazione.getLocation();
                } catch (MalformedURLException e) {
                    answer = "Errore: malformazione dell'URL: \n \n \n";
                    answer += e.getMessage();
                }

                lblCoord.setText(answer);
            }
        });*/

    }
}