package com.example.infduttom1610.unittester;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.server_client_communication.Comm;

import java.net.MalformedURLException;

public class QR_Data extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr__data);

        Button btnSendQR = findViewById(R.id.btnSendQR);
        final TextView lblResult = findViewById(R.id.lblQR);

        btnSendQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Comm comu = new Comm();
                    lblResult.setText(comu.send());
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            }
        });

        //http://www.ilterzocchio.it/pagina.php?idPagina=20
    }
}
